#!/bin/bash

./start.sh WesGilster "TestKit"
