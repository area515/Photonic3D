#!/bin/bash

start.sh WesGilster downgrade