#!/bin/bash

./start.sh area515 "debug"
