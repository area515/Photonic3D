#!/bin/bash

start.sh WesGilster