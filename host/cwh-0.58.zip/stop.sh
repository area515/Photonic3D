#!/bin/bash

pkill org.area515.resinprinter.server.Main